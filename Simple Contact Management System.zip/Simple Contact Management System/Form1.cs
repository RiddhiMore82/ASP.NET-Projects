﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Simple_Contact_Management_System
{
    public partial class Form1 : Form
    {
        private string connectionString = @"Data Source=DESKTOP-SC100GF\SQLEXPRESS;Initial Catalog=ContactDB;Integrated Security=True;";

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Add_Click_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Contacts (Name, PhoneNumber, Email) VALUES (@Name, @PhoneNumber, @Email)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Contact Added Successfully..!");
                ClearFields();
                LoadContacts();
            }
        }

        private void btn_Update_Click_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Contacts SET Name = @Name, PhoneNumber = @PhoneNumber, Email = @Email WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", txtId.Text);
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Contacts Updated Successfully.");
                ClearFields();
                LoadContacts();
            }
        }

        private void btn_Delete_Click_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Contacts WHERE Id = @Id;";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", txtId.Text);

                conn.Open() ;
                cmd.ExecuteNonQuery() ;
                MessageBox.Show("Contact Deleted Successfully.");
                ClearFields();
                LoadContacts();
            }
        }

        private void btn_View_Click_Click(object sender, EventArgs e)
        {
            LoadContacts();
        }

        private void ClearFields()
        {
            txtId.Clear();
            txtName.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
        }

        private void LoadContacts()
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Contacts;";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvContacts.DataSource = dt;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'contactDBDataSet.Contacts' table. You can move, or remove it, as needed.
            this.contactsTableAdapter.Fill(this.contactDBDataSet.Contacts);

        }
    }
}
