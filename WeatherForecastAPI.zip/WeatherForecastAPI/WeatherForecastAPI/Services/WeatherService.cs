﻿using WeatherForecastAPI.Models;

namespace WeatherForecastAPI.Services
{
    public class WeatherService
    {
        private static readonly Dictionary<string, WeatherForecastModel> WeatherData = new Dictionary<string, WeatherForecastModel>
        {
            { "New York", new WeatherForecastModel { City = "New York", Weather = "Sunny", Description = "Clear sky", Temperature = 25.3, WindSpeed = 5.2 } },
            { "London", new WeatherForecastModel { City = "London", Weather = "Cloudy", Description = "Overcast clouds", Temperature = 18.1, WindSpeed = 3.5 } },
            { "Tokyo", new WeatherForecastModel { City = "Tokyo", Weather = "Rainy", Description = "Light rain", Temperature = 22.0, WindSpeed = 7.0 } }
        };

        public WeatherForecastModel GetWeatherByCity(string city)
        {
            if (WeatherData.TryGetValue(city, out var weather))
            {
                return weather;
            }
            return null;
        }
    }
}
