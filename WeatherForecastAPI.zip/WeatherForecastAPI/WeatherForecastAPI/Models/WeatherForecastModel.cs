﻿namespace WeatherForecastAPI.Models
{
    public class WeatherForecastModel
    {
        public string City { get; set; } = string.Empty;
        public string Weather { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public double Temperature { get; set; }
        public double WindSpeed { get; set; }
    }
}
