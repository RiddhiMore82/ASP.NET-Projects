using Microsoft.AspNetCore.Mvc;
using WeatherForecastAPI.Models;
using WeatherForecastAPI.Services;

namespace WeatherForecastAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly WeatherService _weatherService;

        public WeatherForecastController()
        {
            _weatherService = new WeatherService();
        }

        [HttpGet("{city}")]
        public IActionResult GetWeather(string city)
        {
            var weather = _weatherService.GetWeatherByCity(city);

            if (weather == null)
            {
                return NotFound(new { message = "City not found" });
            }

            return Ok(weather);
        }
    }
}
