﻿using System;
using System.Windows;


namespace Simple_Calculator_with_History
{
    public partial class MainWindow : Window
    {
        private string currentInput = string.Empty;
        private string currentOperation = string.Empty;
        private double lastResult = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void Number_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            currentInput += button.Content.ToString();
            txtDisplay.Text = currentInput;
        }

        public void Operation_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            if (!string.IsNullOrEmpty(currentInput))
            {
                lastResult = double.Parse(currentInput);
                currentOperation = button.Content.ToString();
                currentInput = string.Empty;
            }
        }

        public void Equals_Click(object sender, RoutedEventArgs e)
        {
            if(!string.IsNullOrEmpty(currentInput) && !string.IsNullOrEmpty(currentOperation))
            {
                double currentNumber = double.Parse(currentInput);
                double result = 0;

                switch (currentOperation)
                {
                    case "+":
                        result = lastResult + currentNumber;
                        break;

                    case "-":
                        result = lastResult - currentNumber;
                        break;

                    case "*":
                        result = lastResult * currentNumber;
                        break;

                    case "/":
                        result = lastResult / currentNumber;
                        break;
                }

                txtDisplay.Text = result.ToString();
                lstHistory.Items.Add($"{lastResult} {currentOperation} {currentInput} = {result}");
                lastResult = result;
                currentInput = string.Empty;
                currentOperation = string.Empty;
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            txtDisplay.Text = string.Empty;
            currentInput = string.Empty;
            lastResult = 0;
            currentOperation = string.Empty;
        }

        private void ClearHistory_Click(object sender, RoutedEventArgs e)
        {
            lstHistory.Items.Clear();
        }
    }
}
